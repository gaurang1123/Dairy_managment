﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    public partial class AccountMst : Form
    {
        string uname = "";
        int val;
        DS.DS_LOGIN.LOGINMST_SELECTDataTable LDT = new MILKSYSTEM.DS.DS_LOGIN.LOGINMST_SELECTDataTable();
        DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter LAdapter = new MILKSYSTEM.DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter();

        DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable AccDT = new MILKSYSTEM.DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable();
        DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter AccAdapter = new MILKSYSTEM.DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter();

        DS.DS_ACCOUNT.ACCOUNTMST_SELECT_MAX_AIDDataTable AMDT = new MILKSYSTEM.DS.DS_ACCOUNT.ACCOUNTMST_SELECT_MAX_AIDDataTable();
        DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECT_MAX_AIDTableAdapter AMAdapter = new MILKSYSTEM.DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECT_MAX_AIDTableAdapter();

        public AccountMst(string unamee,int a)
        {
            InitializeComponent();
            uname = unamee;
            val = a;
        }

        private void UserMst_Load(object sender, EventArgs e)
        {
            if (val == 1)
            {
                tabControl1.SelectedIndex = 1;
                AccDT = AccAdapter.Select();
                comboBox1.DataSource = AccDT;
                comboBox1.DisplayMember = "AID";
                comboBox1.ValueMember = "AID";
                comboBox1.Text = "SELECT";
            }
            else if (val == 2)
            {
                tabControl1.SelectedIndex = 2;
                AccDT = AccAdapter.Select();
                drpdelete.DataSource = AccDT;
                drpdelete.DisplayMember = "AID";
                drpdelete.ValueMember = "AID";
                drpdelete.Text = "SELECT";
            }
            else if (val == 3)
            {
                tabControl1.SelectedIndex = 3;
                AccDT = AccAdapter.Select();

                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = AccDT;
            }
            else if (val == 0)
            {
                tabControl1.SelectedIndex = 0;
                txtafname.Focus();
                //AMDT = AMAdapter.select();
                //if (AMDT.Rows[0]["AID"].ToString() == "")
                //{
                //    txtaccountno.Text = "1";
                //}
                //else
                //{
                //    int no = Convert.ToInt32(AMDT.Rows[0]["AID"].ToString()) + 1;
                //    txtaccountno.Text = no.ToString();
                //}
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            txtaaddress.Text = "";
            txtamobile.Text = "";
            txtalname.Text = "";
            txtafname.Text = "";
            txtafname.Focus();
            tabControl1.SelectedIndex = 0;
            //AMDT = AMAdapter.select();
            //if (AMDT.Rows[0]["AID"].ToString() == "")
            //{
            //    txtaccountno.Text = "1";
            //}
            //else
            //{
            //    int no = Convert.ToInt32(AMDT.Rows[0]["AID"].ToString()) + 1;
            //    txtaccountno.Text = no.ToString();
            //}
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            AccDT = AccAdapter.Select();
            comboBox1.DataSource = AccDT;
            comboBox1.DisplayMember = "AID";
            comboBox1.ValueMember = "AID";
            comboBox1.Text = "SELECT";
            tabControl1.SelectedIndex = 1;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

            AccDT = AccAdapter.Select();
            drpdelete.DataSource = AccDT;
            drpdelete.DisplayMember = "AID";
            drpdelete.ValueMember = "AID";
            drpdelete.Text = "SELECT";
            tabControl1.SelectedIndex = 2;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            AccDT = AccAdapter.Select();

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = AccDT;
            tabControl1.SelectedIndex = 3;
        }

        private void btnadduser_Click(object sender, EventArgs e)
        {
            if (txtafname.Text == "")
            {
                MessageBox.Show("Please, Enter your First Name !!", "Milk Management System");
            }
            else if (txtalname.Text == "")
            {
                MessageBox.Show("Please, Enter your Last Name !!", "Milk Management System");
            }
            else if (txtaaddress.Text == "")
            {
                MessageBox.Show("Please, Enter your Address !!", "Milk Management System");
            }
            else if (txtamobile.Text == "")
            {
                MessageBox.Show("Please, Enter your Mobile", "Milk Management System");
            }
            else if (comboBox2.Text == "SELECT")
            {
                MessageBox.Show("Please, Select Cattle Type", "Milk Management System");
            
            }
            else
            {

                int insertuser = AccAdapter.Insert(txtafname.Text, txtalname.Text, txtaaddress.Text, txtamobile.Text, comboBox2.Text);
              //  MessageBox.Show("Account Detail Added Successfully !!", "Milk Management System");
                txtaaddress.Text = "";
                txtamobile.Text = "";
                txtalname.Text = "";
                txtafname.Text = "";
                txtafname.Focus();

                AMDT = AMAdapter.select();
                if (AMDT.Rows[0]["AID"].ToString() == "")
                {
                    MessageBox.Show("Account Detail Added Successfully </br> Your Member Account No = 1", "Milk Management System"); 
                }
                else
                {
                    MessageBox.Show(" Account Detail Added Successfully"+ System.Environment.NewLine +"Your Member Account No = " + AMDT.Rows[0]["AID"].ToString(), "Milk Management System"); 
                  //  int no = Convert.ToInt32(AMDT.Rows[0]["AID"].ToString()) + 1;
                   // txtaccountno.Text = no.ToString();
                }
            }

        }

        private void btneditt_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "SELECT")
            {
                MessageBox.Show("Select Member Account !!", "Milk Management System");

            }
            else
            {
                AccDT = AccAdapter.SelectBy_ID(Convert.ToInt32(comboBox1.SelectedValue));
                txtefname.Text = AccDT.Rows[0]["fname"].ToString();
                txtelname.Text = AccDT.Rows[0]["lname"].ToString();
                txteadd.Text = AccDT.Rows[0]["address"].ToString();
                txtemobile.Text = AccDT.Rows[0]["mobile"].ToString();
                gvupdate.Visible = true;
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtefname.Text == "")
            {
                MessageBox.Show("Enter First Name !!", "Milk Management System");
            }
            else if (txtelname.Text == "")
            { MessageBox.Show("Enter Last Name !!", "Milk Management System"); }
            else if (comboBox3.Text == "")
            {
                MessageBox.Show("Select Catle Type !!", "Milk Management System"); 
            }
            else
            {
                int edit = AccAdapter.Update(Convert.ToInt32(comboBox1.SelectedValue), txtefname.Text, txtelname.Text, txteadd.Text, txtemobile.Text, comboBox3.Text);
                MessageBox.Show("Account Detail Updated Successfully !!", "Milk Management System");
                gvupdate.Visible = false;
            }
        }

        private void btndelte_Click(object sender, EventArgs e)
        {
            if (drpdelete.Text == "SELECT")
            {
                MessageBox.Show("Select Member Account !!", "Milk Management System");

            }

            else
            {
                btndelte.Visible = false;
                label17.Text = "";
                label17.Visible = false;
                int dell = AccAdapter.Delete(Convert.ToInt32(drpdelete.SelectedValue));
                MessageBox.Show("Account Deleted Successfully !!", "Milk Management System");
                AccDT = AccAdapter.Select();
                drpdelete.DataSource = AccDT;
                drpdelete.DisplayMember = "AID";
                drpdelete.ValueMember = "AID";
                drpdelete.Text = "SELECT";

            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

            DS.DS_ACCOUNT.ACCOUNTMST_SELECT_MAX_AIDDataTable AMDT = new MILKSYSTEM.DS.DS_ACCOUNT.ACCOUNTMST_SELECT_MAX_AIDDataTable();
            DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECT_MAX_AIDTableAdapter AMAdapter = new MILKSYSTEM.DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECT_MAX_AIDTableAdapter();
            if (tabControl1.SelectedIndex == 0)
            {
                //AMDT = AMAdapter.select();
                //if (AMDT.Rows[0]["AID"].ToString() == "")
                //{
                //    txtaccountno.Text = "1";
                //}
                //else
                //{
                //    int no = Convert.ToInt32(AMDT.Rows[0]["AID"].ToString()) + 1;
                //    txtaccountno.Text = no.ToString();

                //}
                txtamobile.Text = "";
                txtaaddress.Text = "";
                txtalname.Text = "";
                txtafname.Text = "";
                txtafname.Focus();

            }
            else if (tabControl1.SelectedIndex == 1)
            {
                AccDT = AccAdapter.Select();
                comboBox1.DataSource = AccDT;
                comboBox1.DisplayMember = "AID";
                comboBox1.ValueMember = "AID";
                comboBox1.Text = "SELECT";
            }
            else if (tabControl1.SelectedIndex == 2)
            {
                AccDT = AccAdapter.Select();
                drpdelete.DataSource = AccDT;
                drpdelete.DisplayMember = "AID";
                drpdelete.ValueMember = "AID";
                drpdelete.Text = "SELECT";
            }
            else if (tabControl1.SelectedIndex == 3)
            {
                AccDT = AccAdapter.Select();

                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = AccDT;
            }
        }

        private void drpdelete_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (drpdelete.Text == "SELECT")
            {
                MessageBox.Show("plz select account number");
            }
            else
            {
                AccDT = AccAdapter.SelectBy_ID(Convert.ToInt32(drpdelete.SelectedValue));
                label17.Text = "Name = " + AccDT.Rows[0]["fname"].ToString() + " " + AccDT.Rows[0]["lname"].ToString();
                btndelte.Visible = true;
                label17.Visible = true;
            }



        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
