﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    public partial class Setting : Form
    {
        string uname = "";
        string uid = "";
        int id;
        DS.DS_LOGIN.LOGINMST_SELECTDataTable LDT = new MILKSYSTEM.DS.DS_LOGIN.LOGINMST_SELECTDataTable();
        DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter LAdapter = new MILKSYSTEM.DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter();

        DS.DS_FAT.FATEMST_SELETEDataTable FDT = new MILKSYSTEM.DS.DS_FAT.FATEMST_SELETEDataTable();
        DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter FAdapter = new MILKSYSTEM.DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter();
        public Setting(string unamee,string uidd,int idd)
        {
            InitializeComponent();
            uname = unamee;
            uid = uidd;
            id = idd;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
        
            tabControl1.SelectedIndex = 3;
        }

        private void btnadduser_Click(object sender, EventArgs e)
        {
            if (txtfateprice.Text == "")
            {
                MessageBox.Show("Please, Enter fate price !!", "Milk Management System");
            }
            
           else
            {

                int frice = FAdapter.Update(Convert.ToDouble(txtfateprice.Text));
                MessageBox.Show("Fate Price Changed Successfully !!", "Milk Management System");
                txtfateprice.Text = ""; 
                txtfateprice.Focus();
                if (FDT.Rows.Count == 0)
                {
                    TXTCURRENTFATE.Text = "0";
                    tabControl1.SelectedIndex = 0;
                }
                else
                {
                    TXTCURRENTFATE.Text = FDT.Rows[0]["FATPRICE"].ToString();
                    tabControl1.SelectedIndex = 0;
                }
            
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                if (FDT.Rows.Count == 0)
                {
                    TXTCURRENTFATE.Text = "0";
                    tabControl1.SelectedIndex = 0;
                }
                else
                {
                    TXTCURRENTFATE.Text = FDT.Rows[0]["FATPRICE"].ToString();
                    tabControl1.SelectedIndex = 0;
                }
                txtfateprice.Text = "";
                txtfateprice.Focus();
            
            }
            else if (tabControl1.SelectedIndex == 1)
            {
                
            }
            else if (tabControl1.SelectedIndex == 2)
            {
              
            }
            else if (tabControl1.SelectedIndex == 3)
            {
              
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (FDT.Rows.Count == 0)
            {
                TXTCURRENTFATE.Text = "0";
                tabControl1.SelectedIndex = 0;
            }
            else
            {
                TXTCURRENTFATE.Text = FDT.Rows[0]["FATPRICE"].ToString();
                tabControl1.SelectedIndex = 0;
            }
            txtfateprice.Text = "";
            txtfateprice.Focus();
            tabControl1.SelectedIndex = 0;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
           
            tabControl1.SelectedIndex = 1;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
           
            tabControl1.SelectedIndex = 2;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (txtnewpass.Text == txtconfpas.Text)
            {
                LAdapter.LOGINMST_CHANGE_PASSWORD(Convert.ToInt32(uid), txtnewpass.Text);
                MessageBox.Show("Password Changed Successfully !!", "Milk Management System");
                txtnewpass.Text = "";
                txtconfpas.Text = "";
            }
            else
            {
                MessageBox.Show("Password not same !!", "Milk Management System");
            }
        }

        private void btndelte_Click(object sender, EventArgs e)
        {
         
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
          

        }

        private void btneditt_Click(object sender, EventArgs e)
        {
          
        }

        private void Setting_Load(object sender, EventArgs e)
        {
            if (id == 0)
            {

                FDT = FAdapter.Select();
                if (FDT.Rows.Count == 0)
                {
                    TXTCURRENTFATE.Text = "0";
                    tabControl1.SelectedIndex = 0;
                }
                else
                {
                    TXTCURRENTFATE.Text = FDT.Rows[0]["FATPRICE"].ToString();
                    tabControl1.SelectedIndex = 0;
                }
            }
            else
            {
                tabControl1.SelectedIndex = 1;

            }
        }

      

       
    }
}
