﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    public partial class UserMst : Form
    {
        string uname = "";
        int id;
        DS.DS_LOGIN.LOGINMST_SELECTDataTable LDT = new MILKSYSTEM.DS.DS_LOGIN.LOGINMST_SELECTDataTable();
        DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter LAdapter = new MILKSYSTEM.DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter();

        public UserMst(string unamee,int idd)
        {
            InitializeComponent();
            uname = unamee;
            id = idd;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            LDT = LAdapter.Select();

            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = LDT;
            tabControl1.SelectedIndex = 3;
        }

        private void btnadduser_Click(object sender, EventArgs e)
        {
            if (txtafname.Text == "")
            {
                MessageBox.Show("Please, Enter your First Name !!", "Milk Management System");
            }
            else if (txtalname.Text == "")
            {
                MessageBox.Show("Please, Enter your Last Name !!", "Milk Management System");
            }
            else if (txtauname.Text == "")
            {
                MessageBox.Show("Please, Enter your UserName !!", "Milk Management System");
            }
            else if (txtaupass.Text == "")
            {
                MessageBox.Show("Please, Enter your Password", "Milk Management System");
            }
           else
            {
                
                int insertuser = LAdapter.Insert(txtafname.Text, txtalname.Text, txtauname.Text, txtaupass.Text);
                MessageBox.Show("User Detail Added Successfully !!", "Milk Management System");
                txtaupass.Text = "";
                txtauname.Text = "";
                txtalname.Text = "";
                txtafname.Text = ""; 
                txtafname.Focus();
            
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                txtaupass.Text = "";
                txtauname.Text = "";
                txtalname.Text = "";
                txtafname.Text = "";
                txtafname.Focus();
            
            }
            else if (tabControl1.SelectedIndex == 1)
            {
                LDT = LAdapter.Select();
                comboBox1.DataSource = LDT;
                comboBox1.DisplayMember = "uname";
                comboBox1.ValueMember = "uid";
                comboBox1.Text = "SELECT";
            }
            else if (tabControl1.SelectedIndex == 2)
            {
                LDT = LAdapter.Select();
                drpdelete.DataSource = LDT;
                drpdelete.DisplayMember = "uname";
                drpdelete.ValueMember = "uid";
                drpdelete.Text = "SELECT";
            }
            else if (tabControl1.SelectedIndex == 3)
            {
                LDT = LAdapter.Select();
              
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = LDT;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            txtaupass.Text = "";
            txtauname.Text = "";
            txtalname.Text = "";
            txtafname.Text = "";
            txtafname.Focus();
            tabControl1.SelectedIndex = 0;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            LDT = LAdapter.Select();
            comboBox1.DataSource = LDT;
            comboBox1.DisplayMember = "uname";
            comboBox1.ValueMember = "uid";
            comboBox1.Text = "SELECT";
            tabControl1.SelectedIndex = 1;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            LDT = LAdapter.Select();
            drpdelete.DataSource = LDT;
            drpdelete.DisplayMember = "uname";
            drpdelete.ValueMember = "uid";
            drpdelete.Text = "SELECT";
            tabControl1.SelectedIndex = 2;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            int edit = LAdapter.Update(Convert.ToInt32(comboBox1.SelectedValue), txtefname.Text, txtelname.Text);
            MessageBox.Show("USer Detail Updated Successfully !!", "Milk Management System");
            gvupdate.Visible = false;
        }

        private void btndelte_Click(object sender, EventArgs e)
        {
            if (drpdelete.Text == "SELECT")
            {
                MessageBox.Show("Select User Account !!", "Milk Management System");
            
            }
            else if (drpdelete.Text == uname.ToString())
            {
                MessageBox.Show("You can't delete your Account !!", "Milk Management System");
            }
            else
            {
               int dell= LAdapter.Delete(Convert.ToInt32(drpdelete.SelectedValue));
               MessageBox.Show("User Deleted Successfully !!", "Milk Management System");
               LDT = LAdapter.Select();
               drpdelete.DataSource = LDT;
               drpdelete.DisplayMember = "uname";
               drpdelete.ValueMember = "uid";
               drpdelete.Text = "SELECT";
            }
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
          

        }

        private void btneditt_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "SELECT")
            {
                MessageBox.Show("Select User Account !!", "Milk Management System");

            }
            else
            {
                LDT = LAdapter.Select_By_UID(Convert.ToInt32(comboBox1.SelectedValue));
                txtefname.Text = LDT.Rows[0]["fname"].ToString();
                txtelname.Text = LDT.Rows[0]["lname"].ToString();
                gvupdate.Visible = true;
            }
        }

        private void UserMst_Load(object sender, EventArgs e)
        {
            if (id == 0)
            {
                tabControl1.SelectedIndex = 0;
            
            }
            else if (id == 1)
            {
                tabControl1.SelectedIndex = 1;
            }
            else if (id == 2)
            {
                tabControl1.SelectedIndex = 2;
            }
            else if (id == 3)
            {
                tabControl1.SelectedIndex = 3;
            
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

       
    }
}
