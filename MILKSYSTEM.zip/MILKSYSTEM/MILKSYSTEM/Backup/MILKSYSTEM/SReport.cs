﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    public partial class SReport : Form
    {
        DS.DS_SALARY.SALARYMST_MAX_STATUSDataTable MDT = new MILKSYSTEM.DS.DS_SALARY.SALARYMST_MAX_STATUSDataTable();
        DS.DS_SALARYTableAdapters.SALARYMST_MAX_STATUSTableAdapter MAdapter = new MILKSYSTEM.DS.DS_SALARYTableAdapters.SALARYMST_MAX_STATUSTableAdapter();
       
        DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable AccDT = new MILKSYSTEM.DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable();
        DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter AccAdapter = new MILKSYSTEM.DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter();

        DS.DS_FAT.FATEMST_SELETEDataTable FDT = new MILKSYSTEM.DS.DS_FAT.FATEMST_SELETEDataTable();
        DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter FAdapter = new MILKSYSTEM.DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter();

        DS.DS_BUY.BUYMST_SELETEDataTable BDT = new MILKSYSTEM.DS.DS_BUY.BUYMST_SELETEDataTable();
        DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter BAdapter = new MILKSYSTEM.DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter();

        DS.DS_SALARY.SALARYMST_SELETEDataTable SDT = new MILKSYSTEM.DS.DS_SALARY.SALARYMST_SELETEDataTable();
        DS.DS_SALARYTableAdapters.SALARYMST_SELETETableAdapter SAdapter = new MILKSYSTEM.DS.DS_SALARYTableAdapters.SALARYMST_SELETETableAdapter();

        DS.DS_SALARY.SALARY_SELECT_SEARCHDataTable SearchDT = new MILKSYSTEM.DS.DS_SALARY.SALARY_SELECT_SEARCHDataTable();
        DS.DS_SALARYTableAdapters.SALARY_SELECT_SEARCHTableAdapter SearchAdapter = new MILKSYSTEM.DS.DS_SALARYTableAdapters.SALARY_SELECT_SEARCHTableAdapter();
        //   DS.DS_SMSTTableAdapters. SMAdapter = new MILKSYSTEM.DS.DS_SMSTTableAdapters.SMST_SELETETableAdapter();
        public SReport(string unamee)
        {
            InitializeComponent();
          // uname = unamee;
        }

        private void SReport_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtaid.Text == "" && txtfname.Text == "")
            {
                MessageBox.Show("Input Some Values for Search ");
                GvToday.AutoGenerateColumns = false;
                GvToday.DataSource = null;
                lblmsg.Text = "Result = 0";
            }
            else
            {
                if (txtfname.Text != "" && txtaid.Text != "")
                {

                    SearchDT = SearchAdapter.Select_SEARCH(0, txtfname.Text + "%", Convert.ToInt32(txtaid.Text));
                    GvToday.AutoGenerateColumns = false;
                    GvToday.DataSource = SearchDT;

                }
                else if (txtfname.Text == "" && txtaid.Text != "")
                {
                    SearchDT = SearchAdapter.Select_SEARCH(2, txtfname.Text + "%", Convert.ToInt32(txtaid.Text));
                    GvToday.AutoGenerateColumns = false;
                    GvToday.DataSource = SearchDT;
                }
                else if (txtfname.Text != "" && txtaid.Text == "")
                {
                    SearchDT = SearchAdapter.Select_SEARCH(1, txtfname.Text + "%", 0);
                    GvToday.AutoGenerateColumns = false;
                    GvToday.DataSource = SearchDT;
                }
                lblmsg.Text = "Result = " + SearchDT.Rows.Count.ToString();
            }
        }

       

    }
}
