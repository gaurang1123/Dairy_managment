﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    public partial class Salary : Form
    {
        DS.DS_SALARY.SALARYMST_MAX_STATUSDataTable MDT = new MILKSYSTEM.DS.DS_SALARY.SALARYMST_MAX_STATUSDataTable();
        DS.DS_SALARYTableAdapters.SALARYMST_MAX_STATUSTableAdapter MAdapter = new MILKSYSTEM.DS.DS_SALARYTableAdapters.SALARYMST_MAX_STATUSTableAdapter();
       
        DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable AccDT = new MILKSYSTEM.DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable();
        DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter AccAdapter = new MILKSYSTEM.DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter();

        DS.DS_FAT.FATEMST_SELETEDataTable FDT = new MILKSYSTEM.DS.DS_FAT.FATEMST_SELETEDataTable();
        DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter FAdapter = new MILKSYSTEM.DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter();

        DS.DS_BUY.BUYMST_SELETEDataTable BDT = new MILKSYSTEM.DS.DS_BUY.BUYMST_SELETEDataTable();
        DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter BAdapter = new MILKSYSTEM.DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter();

        DS.DS_SALARY.SALARYMST_SELETEDataTable SDT = new MILKSYSTEM.DS.DS_SALARY.SALARYMST_SELETEDataTable();
        DS.DS_SALARYTableAdapters.SALARYMST_SELETETableAdapter SAdapter = new MILKSYSTEM.DS.DS_SALARYTableAdapters.SALARYMST_SELETETableAdapter();

        DS.DS_SMST.SMST_SELETEDataTable SMDT = new MILKSYSTEM.DS.DS_SMST.SMST_SELETEDataTable();
        DS.DS_SMSTTableAdapters.SMST_SELETETableAdapter SMAdapter = new MILKSYSTEM.DS.DS_SMSTTableAdapters.SMST_SELETETableAdapter();
        public Salary(string unamee)
        {
            InitializeComponent();
          // uname = unamee;
        }

        private void Buy_Load(object sender, EventArgs e)
        {
            MDT = MAdapter.Select_MAX_DATE();
            if (MDT.Rows.Count != 0)
            {
                dateTimePicker1.Text = MDT.Rows[0]["MDATE"].ToString();
            }
            else
            {
                dateTimePicker1.Text = System.DateTime.Now.ToString();
            }


            
      
        }

        private void button1_Click(object sender, EventArgs e)
        {

            BDT = BAdapter.Select_FOR_SALARY(Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text));

            GvToday.AutoGenerateColumns = false;
            GvToday.DataSource = BDT;
            double ltrr = 0,prcc=0;
            for (int i = 0; i < BDT.Rows.Count; i++)
            { 
            ltrr=ltrr+Convert.ToDouble(BDT.Rows[i]["Liter"].ToString());
            prcc = prcc + Convert.ToDouble(BDT.Rows[i]["TPrice"].ToString());
            }
            lblacc.Text = "Total = " + BDT.Rows.Count;
            lblltr.Text = ltrr.ToString();
            lblprice.Text = prcc.ToString();

            if (BDT.Rows.Count > 0)
            {

                button2.Enabled = true;
            }
            else
            {
                button2.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult rst = MessageBox.Show("Confirm to Generate Salary !!", "MILK", MessageBoxButtons.OKCancel);
            if (rst == DialogResult.OK)
            {


                BDT = BAdapter.SelectFor_SALARY_Price_and_Liter(Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text));

                int day = Convert.ToDateTime(dateTimePicker2.Text).DayOfYear - Convert.ToDateTime(dateTimePicker1.Text).DayOfYear;
                double ltr = 0;
                double prc = 0;
                for (int i = 0; i < BDT.Rows.Count; i++)
                {
                    // BDT=BAdapter.SelectFor_SALARY_Price_and_Liter(Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text),Convert.ToInt32(BDT.Rows[i]["AID"].ToString()));

                    //insert to salarymst
                    int salary = SAdapter.Insert(Convert.ToInt32(BDT.Rows[i]["AID"].ToString()), Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text), day, Convert.ToDouble(BDT.Rows[i]["Liter"].ToString()), Convert.ToDouble(BDT.Rows[i]["Fat"].ToString()), Convert.ToDouble(BDT.Rows[i]["TPrice"].ToString()));
                    ltr = ltr + Convert.ToDouble(BDT.Rows[i]["Liter"].ToString());
                    prc = prc + Convert.ToDouble(BDT.Rows[i]["TPrice"].ToString());
                }

                //update status in buy mst
                BDT = BAdapter.Select_FOR_SALARY(Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text));
                int acc = 0;
                for (int i = 0; i < BDT.Rows.Count; i++)
                {
                    BAdapter.BUYMST_UPDATE_STATUS(Convert.ToInt32(BDT.Rows[i]["BID"].ToString()), 1);
                    acc = acc + 1;
                }

                //inset into smst
                int sminst = SMAdapter.Insert(Convert.ToDateTime(dateTimePicker1.Text), Convert.ToDateTime(dateTimePicker2.Text), acc, ltr, prc);
                GvToday.DataSource = null;
            
            }
            else
            {
            }
        }
  

    }
}
