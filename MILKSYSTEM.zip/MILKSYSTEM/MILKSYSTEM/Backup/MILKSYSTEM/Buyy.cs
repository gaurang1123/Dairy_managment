﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    public partial class Buyy : Form
    {
        DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable AccDT = new MILKSYSTEM.DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable();
        DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter AccAdapter = new MILKSYSTEM.DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter();

        DS.DS_FAT.FATEMST_SELETEDataTable FDT = new MILKSYSTEM.DS.DS_FAT.FATEMST_SELETEDataTable();
        DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter FAdapter = new MILKSYSTEM.DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter();

        DS.DS_BUY.BUYMST_SELETEDataTable BDT = new MILKSYSTEM.DS.DS_BUY.BUYMST_SELETEDataTable();
        DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter BAdapter = new MILKSYSTEM.DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter();
        public Buyy(string unamee)
        {
            InitializeComponent();
          // uname = unamee;
        }

        private void Buy_Load(object sender, EventArgs e)
        {
          
        
            double tprice = 0, tltr = 0;
            for (int i = 0; i < BDT.Rows.Count;i++ )
            {
                tltr = tltr + Convert.ToDouble(BDT.Rows[i]["liter"].ToString());
                tprice = tprice + Convert.ToDouble(BDT.Rows[i]["tprice"].ToString());

            }
           // lbltltr.Text = tltr.ToString();
           // lbltprice.Text = tprice.ToString();
            //lbltotal.Text = "Total = " + BDT.Rows.Count.ToString();
           // 
        

            
        }

      
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                lblname.Text = "";
                lbladdress.Text = "";
             
            }
            else
            {
                AccDT = AccAdapter.SelectBy_ID(Convert.ToInt32(textBox1.Text));
                if (AccDT.Rows.Count == 1)
                {
                    lblname.Text = "Name : " + AccDT.Rows[0]["fname"].ToString() + " " + AccDT.Rows[0]["lname"].ToString();
                    lbladdress.Text = "Address : " + AccDT.Rows[0]["Address"].ToString();
                
                }
                else
                {
                
                    lblname.Text = "";
                    lbladdress.Text = "";
               
                   // textBox1.Text = "";
                }
            }
        }

        private void txtfate_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtfate_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if(textBox1.Text!="")
            {
               

            BDT=BAdapter.Select_AID_and_STATUS(Convert.ToInt32(textBox1.Text),0);
            GvAccount.AutoGenerateColumns = false;
            GvAccount.DataSource = BDT;


            double tprice = 0, tltr = 0;
            for (int i = 0; i < BDT.Rows.Count; i++)
            {
                tltr = tltr + Convert.ToDouble(BDT.Rows[i]["liter"].ToString());
                tprice = tprice + Convert.ToDouble(BDT.Rows[i]["tprice"].ToString());

            }
            lblltr.Text = tltr.ToString();
            lblprice.Text = tprice.ToString();
            lblacc.Text = "Total = " + BDT.Rows.Count.ToString();
            
            }

        }

     

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GvAccount_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void GvAccount_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (GvAccount.Rows[e.RowIndex].Cells[6].Selected == true)
                {
                    int bid =Convert.ToInt32( GvAccount.Rows[e.RowIndex].Cells[0].Value.ToString());
                    int del = BAdapter.Delete(bid);
                    BDT = BAdapter.Select_AID_and_STATUS(Convert.ToInt32(textBox1.Text), 0);
                    GvAccount.AutoGenerateColumns = false;
                    GvAccount.DataSource = BDT;


                    double tprice = 0, tltr = 0;
                    for (int i = 0; i < BDT.Rows.Count; i++)
                    {
                        tltr = tltr + Convert.ToDouble(BDT.Rows[i]["liter"].ToString());
                        tprice = tprice + Convert.ToDouble(BDT.Rows[i]["tprice"].ToString());

                    }
                    lblltr.Text = tltr.ToString();
                    lblprice.Text = tprice.ToString();
                    lblacc.Text = "Total = " + BDT.Rows.Count.ToString();
                }

            }
            catch (Exception)
            { }
        }

     
       
       
    }
}
