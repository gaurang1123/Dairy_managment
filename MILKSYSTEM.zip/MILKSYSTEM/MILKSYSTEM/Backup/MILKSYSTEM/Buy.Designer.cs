﻿namespace MILKSYSTEM
{
    partial class Buy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbltimee = new System.Windows.Forms.Label();
            this.txtcattle = new System.Windows.Forms.TextBox();
            this.lbldate = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtliter = new System.Windows.Forms.TextBox();
            this.txtfate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txttprice = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.GvAccount = new System.Windows.Forms.DataGridView();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Time = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Literr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fatee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pricee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GvToday = new System.Windows.Forms.DataGridView();
            this.Acc_NO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Liter = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblcnt = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblacc = new System.Windows.Forms.Label();
            this.lblltr = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.lbltprice = new System.Windows.Forms.Label();
            this.lbltltr = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvAccount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GvToday)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.lbltimee);
            this.panel1.Controls.Add(this.txtcattle);
            this.panel1.Controls.Add(this.lbldate);
            this.panel1.Controls.Add(this.lbladdress);
            this.panel1.Controls.Add(this.lblname);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1001, 97);
            this.panel1.TabIndex = 0;
            // 
            // lbltimee
            // 
            this.lbltimee.AutoSize = true;
            this.lbltimee.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltimee.Location = new System.Drawing.Point(709, 49);
            this.lbltimee.Name = "lbltimee";
            this.lbltimee.Size = new System.Drawing.Size(104, 17);
            this.lbltimee.TabIndex = 6;
            this.lbltimee.Text = "Account NO :";
            // 
            // txtcattle
            // 
            this.txtcattle.BackColor = System.Drawing.Color.White;
            this.txtcattle.Enabled = false;
            this.txtcattle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcattle.ForeColor = System.Drawing.Color.Purple;
            this.txtcattle.Location = new System.Drawing.Point(134, 56);
            this.txtcattle.Name = "txtcattle";
            this.txtcattle.ReadOnly = true;
            this.txtcattle.Size = new System.Drawing.Size(100, 20);
            this.txtcattle.TabIndex = 5;
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.Location = new System.Drawing.Point(709, 22);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(104, 17);
            this.lbldate.TabIndex = 4;
            this.lbldate.Text = "Account NO :";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.Location = new System.Drawing.Point(316, 49);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(77, 17);
            this.lbladdress.TabIndex = 3;
            this.lbladdress.Text = "Address :";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(316, 22);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(59, 17);
            this.lblname.TabIndex = 2;
            this.lblname.Text = "Name :";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.ForeColor = System.Drawing.Color.Purple;
            this.textBox1.Location = new System.Drawing.Point(134, 24);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.Click += new System.EventHandler(this.textBox1_Click);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Location = new System.Drawing.Point(28, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Account NO :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "LITTER :";
            // 
            // txtliter
            // 
            this.txtliter.BackColor = System.Drawing.Color.White;
            this.txtliter.ForeColor = System.Drawing.Color.Purple;
            this.txtliter.Location = new System.Drawing.Point(82, 28);
            this.txtliter.Name = "txtliter";
            this.txtliter.Size = new System.Drawing.Size(100, 20);
            this.txtliter.TabIndex = 6;
            // 
            // txtfate
            // 
            this.txtfate.BackColor = System.Drawing.Color.White;
            this.txtfate.ForeColor = System.Drawing.Color.Purple;
            this.txtfate.Location = new System.Drawing.Point(82, 60);
            this.txtfate.Name = "txtfate";
            this.txtfate.Size = new System.Drawing.Size(100, 20);
            this.txtfate.TabIndex = 8;
            this.txtfate.TextChanged += new System.EventHandler(this.txtfate_TextChanged);
            this.txtfate.Click += new System.EventHandler(this.txtfate_Click);
            this.txtfate.Leave += new System.EventHandler(this.txtfate_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "FATE :";
            // 
            // txtprice
            // 
            this.txtprice.BackColor = System.Drawing.Color.White;
            this.txtprice.Enabled = false;
            this.txtprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprice.ForeColor = System.Drawing.Color.Purple;
            this.txtprice.Location = new System.Drawing.Point(354, 27);
            this.txtprice.Name = "txtprice";
            this.txtprice.ReadOnly = true;
            this.txtprice.Size = new System.Drawing.Size(100, 20);
            this.txtprice.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(218, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "PRICE / LITER :";
            // 
            // txttprice
            // 
            this.txttprice.BackColor = System.Drawing.Color.White;
            this.txttprice.Enabled = false;
            this.txttprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttprice.ForeColor = System.Drawing.Color.Purple;
            this.txttprice.Location = new System.Drawing.Point(354, 63);
            this.txttprice.Name = "txttprice";
            this.txttprice.ReadOnly = true;
            this.txttprice.Size = new System.Drawing.Size(100, 20);
            this.txttprice.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(231, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "TOTAL PRICE :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txttprice);
            this.groupBox1.Controls.Add(this.txtliter);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtfate);
            this.groupBox1.Controls.Add(this.txtprice);
            this.groupBox1.Location = new System.Drawing.Point(6, 101);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(467, 95);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // GvAccount
            // 
            this.GvAccount.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GvAccount.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.GvAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvAccount.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date,
            this.Time,
            this.Literr,
            this.Fatee,
            this.Pricee});
            this.GvAccount.Location = new System.Drawing.Point(12, 205);
            this.GvAccount.Name = "GvAccount";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.GvAccount.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.GvAccount.Size = new System.Drawing.Size(448, 332);
            this.GvAccount.TabIndex = 13;
            // 
            // Date
            // 
            this.Date.DataPropertyName = "Date";
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            this.Date.Width = 90;
            // 
            // Time
            // 
            this.Time.DataPropertyName = "Time";
            this.Time.HeaderText = "Time";
            this.Time.Name = "Time";
            this.Time.ReadOnly = true;
            // 
            // Literr
            // 
            this.Literr.DataPropertyName = "Liter";
            this.Literr.HeaderText = "Liter";
            this.Literr.Name = "Literr";
            this.Literr.ReadOnly = true;
            this.Literr.Width = 60;
            // 
            // Fatee
            // 
            this.Fatee.DataPropertyName = "fat";
            this.Fatee.HeaderText = "Fate";
            this.Fatee.Name = "Fatee";
            this.Fatee.ReadOnly = true;
            this.Fatee.Width = 60;
            // 
            // Pricee
            // 
            this.Pricee.DataPropertyName = "tprice";
            this.Pricee.HeaderText = "Price";
            this.Pricee.Name = "Pricee";
            this.Pricee.ReadOnly = true;
            this.Pricee.Width = 90;
            // 
            // GvToday
            // 
            this.GvToday.BackgroundColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GvToday.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.GvToday.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GvToday.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Acc_NO,
            this.Liter,
            this.Fate,
            this.Price});
            this.GvToday.Location = new System.Drawing.Point(539, 123);
            this.GvToday.Name = "GvToday";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GvToday.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Purple;
            this.GvToday.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.GvToday.Size = new System.Drawing.Size(446, 414);
            this.GvToday.TabIndex = 14;
            // 
            // Acc_NO
            // 
            this.Acc_NO.DataPropertyName = "AID";
            this.Acc_NO.HeaderText = "Acc_NO";
            this.Acc_NO.Name = "Acc_NO";
            this.Acc_NO.ReadOnly = true;
            // 
            // Liter
            // 
            this.Liter.DataPropertyName = "Liter";
            this.Liter.HeaderText = "Liter";
            this.Liter.Name = "Liter";
            this.Liter.ReadOnly = true;
            // 
            // Fate
            // 
            this.Fate.DataPropertyName = "fat";
            this.Fate.HeaderText = "Fate";
            this.Fate.Name = "Fate";
            this.Fate.ReadOnly = true;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "tprice";
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            // 
            // lblcnt
            // 
            this.lblcnt.AutoSize = true;
            this.lblcnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnt.ForeColor = System.Drawing.Color.Red;
            this.lblcnt.Location = new System.Drawing.Point(723, 103);
            this.lblcnt.Name = "lblcnt";
            this.lblcnt.Size = new System.Drawing.Size(18, 17);
            this.lblcnt.TabIndex = 15;
            this.lblcnt.Text = "::";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(536, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "TODAY SESSION LIST :";
            // 
            // lblacc
            // 
            this.lblacc.AutoSize = true;
            this.lblacc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblacc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblacc.Location = new System.Drawing.Point(164, 546);
            this.lblacc.Name = "lblacc";
            this.lblacc.Size = new System.Drawing.Size(58, 13);
            this.lblacc.TabIndex = 16;
            this.lblacc.Text = "Total = 0";
            // 
            // lblltr
            // 
            this.lblltr.AutoSize = true;
            this.lblltr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblltr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblltr.Location = new System.Drawing.Point(265, 546);
            this.lblltr.Name = "lblltr";
            this.lblltr.Size = new System.Drawing.Size(14, 13);
            this.lblltr.TabIndex = 17;
            this.lblltr.Text = "0";
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblprice.Location = new System.Drawing.Point(393, 546);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(14, 13);
            this.lblprice.TabIndex = 18;
            this.lblprice.Text = "0";
            // 
            // lbltprice
            // 
            this.lbltprice.AutoSize = true;
            this.lbltprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltprice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbltprice.Location = new System.Drawing.Point(922, 546);
            this.lbltprice.Name = "lbltprice";
            this.lbltprice.Size = new System.Drawing.Size(14, 13);
            this.lbltprice.TabIndex = 19;
            this.lbltprice.Text = "0";
            // 
            // lbltltr
            // 
            this.lbltltr.AutoSize = true;
            this.lbltltr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltltr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbltltr.Location = new System.Drawing.Point(727, 546);
            this.lbltltr.Name = "lbltltr";
            this.lbltltr.Size = new System.Drawing.Size(14, 13);
            this.lbltltr.TabIndex = 20;
            this.lbltltr.Text = "0";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbltotal.Location = new System.Drawing.Point(594, 546);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(58, 13);
            this.lbltotal.TabIndex = 21;
            this.lbltotal.Text = "Total = 0";
            // 
            // Buy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(999, 568);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.lbltltr);
            this.Controls.Add(this.lbltprice);
            this.Controls.Add(this.lblprice);
            this.Controls.Add(this.lblltr);
            this.Controls.Add(this.lblacc);
            this.Controls.Add(this.GvToday);
            this.Controls.Add(this.lblcnt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.GvAccount);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Location = new System.Drawing.Point(140, 73);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Buy";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Load += new System.EventHandler(this.Buy_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GvAccount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GvToday)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.TextBox txtcattle;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtliter;
        private System.Windows.Forms.TextBox txtfate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txttprice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView GvAccount;
        private System.Windows.Forms.Label lbltimee;
        private System.Windows.Forms.DataGridView GvToday;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Time;
        private System.Windows.Forms.DataGridViewTextBoxColumn Literr;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fatee;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pricee;
        private System.Windows.Forms.DataGridViewTextBoxColumn Acc_NO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Liter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.Label lblcnt;
        private System.Windows.Forms.Label lblacc;
        private System.Windows.Forms.Label lblltr;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label lbltprice;
        private System.Windows.Forms.Label lbltltr;
        private System.Windows.Forms.Label lbltotal;


    }
}