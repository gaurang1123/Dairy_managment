﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    public partial class Buy : Form
    {
        DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable AccDT = new MILKSYSTEM.DS.DS_ACCOUNT.ACCOUNTMST_SELECTDataTable();
        DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter AccAdapter = new MILKSYSTEM.DS.DS_ACCOUNTTableAdapters.ACCOUNTMST_SELECTTableAdapter();

        DS.DS_FAT.FATEMST_SELETEDataTable FDT = new MILKSYSTEM.DS.DS_FAT.FATEMST_SELETEDataTable();
        DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter FAdapter = new MILKSYSTEM.DS.DS_FATTableAdapters.FATEMST_SELETETableAdapter();

        DS.DS_BUY.BUYMST_SELETEDataTable BDT = new MILKSYSTEM.DS.DS_BUY.BUYMST_SELETEDataTable();
        DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter BAdapter = new MILKSYSTEM.DS.DS_BUYTableAdapters.BUYMST_SELETETableAdapter();
        public Buy(string unamee)
        {
            InitializeComponent();
          // uname = unamee;
        }



        private void Buy_Load(object sender, EventArgs e)
        {
           // lbldate.Text = System.DateTime.Now.GetDateTimeFormats()[19].ToString();
            lbldate.Text = System.DateTime.Now.Date.ToString();
            BDT = BAdapter.SelectBY_DATE(Convert.ToDateTime(lbldate.Text));
            GvToday.AutoGenerateColumns = false;
            GvToday.DataSource = BDT;
            lblcnt.Text = BDT.Rows.Count.ToString();
        
            double tprice = 0, tltr = 0;
            for (int i = 0; i < BDT.Rows.Count;i++ )
            {
                tltr = tltr + Convert.ToDouble(BDT.Rows[i]["liter"].ToString());
                tprice = tprice + Convert.ToDouble(BDT.Rows[i]["tprice"].ToString());

            }
            lbltltr.Text = tltr.ToString();
            lbltprice.Text = tprice.ToString();
            lbltotal.Text = "Total = " + BDT.Rows.Count.ToString();
            
         // lbldate.Text = "ff";
            if (System.DateTime.Now.GetDateTimeFormats()[106].Length == 7)
            {
            
                if (System.DateTime.Now.GetDateTimeFormats()[106].Substring(5, 2).ToString() == "AM")
                {
                    lbltimee.Text = "MORNING";
                }
                else
                {
                    lbltimee.Text = "EVENING";
                }
            }
            else if (System.DateTime.Now.GetDateTimeFormats()[106].Length == 8)
            {
                if (System.DateTime.Now.GetDateTimeFormats()[106].Substring(6, 2).ToString() == "AM")
                {
                    lbltimee.Text = "MORNING";
                }
                else
                {
                    lbltimee.Text = "EVENING";
                }


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(lbldate.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtfate_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtfate_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if(textBox1.Text!="")
            {
            BDT=BAdapter.Select_AID_and_STATUS(Convert.ToInt32(textBox1.Text),0);
            GvAccount.AutoGenerateColumns = false;
            GvAccount.DataSource = BDT;


            double tprice = 0, tltr = 0;
            for (int i = 0; i < BDT.Rows.Count; i++)
            {
                tltr = tltr + Convert.ToDouble(BDT.Rows[i]["liter"].ToString());
                tprice = tprice + Convert.ToDouble(BDT.Rows[i]["tprice"].ToString());

            }
            lblltr.Text = tltr.ToString();
            lblprice.Text = tprice.ToString();
            lblacc.Text = "Total = " + BDT.Rows.Count.ToString();
            
            }

        }

        private void txtfate_Leave(object sender, EventArgs e)
        {
            if (txtliter.Text == "")
            {
                MessageBox.Show("Enter Liter First !!", "Milk Management System");
            }
            else if (textBox1.Text == "")
            {
                textBox1.Focus();
            
            }
            else
            {
                FDT = FAdapter.Select();
                decimal fprice = Convert.ToDecimal(FDT.Rows[0]["fatprice"].ToString());
                decimal price = Convert.ToDecimal(txtfate.Text) * fprice;
                txtprice.Text = price.ToString();
                decimal tprice = price * Convert.ToDecimal(txtliter.Text);
                txttprice.Text = tprice.ToString();


                DialogResult rst = MessageBox.Show("Confirm Record !!", "MILK", MessageBoxButtons.OKCancel);
                if (rst == DialogResult.OK)
                {

                    int instbuy = BAdapter.Insert(Convert.ToInt32(textBox1.Text), Convert.ToDateTime(lbldate.Text), lbltimee.Text, txtcattle.Text, Convert.ToDouble(txtliter.Text), Convert.ToDouble(txtfate.Text), Convert.ToDouble(price), Convert.ToDouble(tprice));
                    BDT = BAdapter.Select_AID_and_STATUS(Convert.ToInt32(textBox1.Text), 0);
                    GvAccount.AutoGenerateColumns = false;
                    GvAccount.DataSource = BDT;


                    double aprice = 0, altr = 0;
                    for (int i = 0; i < BDT.Rows.Count; i++)
                    {
                        altr = altr + Convert.ToDouble(BDT.Rows[i]["liter"].ToString());
                        aprice = aprice + Convert.ToDouble(BDT.Rows[i]["tprice"].ToString());

                    }
                    lblltr.Text = altr.ToString();
                    lblprice.Text = aprice.ToString();
                    lblacc.Text = "Total = " + BDT.Rows.Count.ToString();


                BDT = BAdapter.SelectBY_DATE(Convert.ToDateTime(lbldate.Text));
                    GvToday.AutoGenerateColumns = false;
                    GvToday.DataSource = BDT;
                    lblcnt.Text = BDT.Rows.Count.ToString();

                    double ttprice = 0, tltr = 0;
                    for (int i = 0; i < BDT.Rows.Count; i++)
                    {
                        tltr = tltr + Convert.ToDouble(BDT.Rows[i]["liter"].ToString());
                        ttprice = ttprice + Convert.ToDouble(BDT.Rows[i]["tprice"].ToString());

                    }
                    lbltltr.Text = tltr.ToString();
                    lbltprice.Text = tprice.ToString();
                    lbltotal.Text = "Total = " + BDT.Rows.Count.ToString();
                }
                else
                {


                }


            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_search_account_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                lblname.Text = "";
                lbladdress.Text = "";
                txtcattle.Text = "";

            }
            else
            {
                AccDT = AccAdapter.SelectBy_ID(Convert.ToInt32(textBox1.Text));
                if (AccDT.Rows.Count == 1)
                {
                    lblname.Text = "Name : " + AccDT.Rows[0]["fname"].ToString() + " " + AccDT.Rows[0]["lname"].ToString();
                    lbladdress.Text = "Address : " + AccDT.Rows[0]["Address"].ToString();
                    txtcattle.Text = AccDT.Rows[0]["cattle"].ToString();
                }
                else
                {
                    txtcattle.Text = "";
                    lblname.Text = "";
                    lbladdress.Text = "";
                    txtliter.Text = "";
                    txtfate.Text = "";
                    // textBox1.Text = "";
                }
            }
        }
    }
}
