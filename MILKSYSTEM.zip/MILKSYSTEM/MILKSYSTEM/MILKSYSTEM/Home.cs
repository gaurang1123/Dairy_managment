﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MILKSYSTEM
{
    
    public partial class Home : Form
    {
        string uname;
        string uid;
        DS.DS_LOGIN.LOGINMST_SELECTDataTable LDT = new MILKSYSTEM.DS.DS_LOGIN.LOGINMST_SELECTDataTable();
        DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter LAdapter = new MILKSYSTEM.DS.DS_LOGINTableAdapters.LOGINMST_SELECTTableAdapter();
        public Home()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            lbltime.Text = System.DateTime.Now.ToString();
            lblday.Text = System.DateTime.Now.DayOfWeek.ToString();



            foreach (Control ctl in this.Controls)
            {
                try
                {
                    System.Windows.Forms.Control Mdi = (MdiClient)ctl;

                    Mdi.BackColor = System.Drawing.Color.White;
                }
                catch (Exception )
                {

                }
            }

        }
        private void closeExistingForm()
        {
            try
            {
                this.ActiveMdiChild.Close();
            }
            catch (Exception)
            {

            }

        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbltime.Text = System.DateTime.Now.AddSeconds(1).ToString();
        }

        private void hOMEToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if (txtname.Text == "")
            {

                MessageBox.Show("Enter Login Name !", "Milk Management System");
            }
            else if (txtpass.Text == "")
            {
                MessageBox.Show("Enter Login Password !", "Milk Management System");
            }
            else
            {
                LDT = LAdapter.Selectfor_LOGIN(txtname.Text, txtpass.Text);

                if (LDT.Rows.Count==1)
                {
uname = txtname.Text;
uid = LDT.Rows[0]["uid"].ToString();
                    txtname.Text = "";
                    txtpass.Text = "";
                    gplogin.Visible = false;
                    menulogout.Visible = true;
                    mENUToolStripMenuItem.Enabled = true;
                    mILKMENUToolStripMenuItem.Enabled = true;
                    sETTINGToolStripMenuItem.Enabled = true;
                    rEPORTSToolStripMenuItem1.Enabled = true;
                    uSERToolStripMenuItem.Enabled = true;
                    label3.Text = "|| WELCOME TO MILK SYSTEM ||";
                    lblname.Text ="Welcome "+ LDT.Rows[0]["fname"].ToString() + " " + LDT.Rows[0]["lname"].ToString();
                    pictureBox2.Visible = true;
                }
                else
                {
                    MessageBox.Show("Invalid LoginName OR Password !", "Milk Management System");
                }
            }
        }

        private void menulogout_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            gplogin.Visible = true;
            menulogout.Visible = false;
            mENUToolStripMenuItem.Enabled = false;
            mILKMENUToolStripMenuItem.Enabled = false;
            sETTINGToolStripMenuItem.Enabled = false;
            rEPORTSToolStripMenuItem1.Enabled = false;
            uSERToolStripMenuItem.Enabled = false;
            label3.Text = "LOGIN TO SYSTEM";
            lblname.Text = "";
            pictureBox1.Visible = true;
            pictureBox2.Visible = false;
        }

        private void nEWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int aa = 0;
            closeExistingForm();
            Form frm2 = new AccountMst(uname,aa);
            frm2.MdiParent = this;
            frm2.Show();
            label3.Text = "";
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
        }

        private void mENUToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void lbltitle_Click(object sender, EventArgs e)
        {

        }

        private void lblday_Click(object sender, EventArgs e)
        {

        }

        private void aDDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new UserMst(uname,0);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void fATPRICEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new Setting(uname,uid,0);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void bUYMILKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new Buy(uname);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void sALLARYToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new Salary(uname);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void eDITToolStripMenuItem_Click(object sender, EventArgs e)
        { int aa=1;
            closeExistingForm();
            Form frm2 = new AccountMst(uname,aa);
            frm2.MdiParent = this;
            frm2.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int aa = 2;
            closeExistingForm();
            Form frm2 = new AccountMst(uname,aa);
            frm2.MdiParent = this;
            frm2.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void rEPORTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int aa = 3;
            closeExistingForm();
            Form frm2 = new AccountMst(uname,aa);
            frm2.MdiParent = this;
            frm2.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void eDITToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new Buyy(uname);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void pASSWORDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new Setting(uname, uid,1);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void eDITToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new UserMst(uname,1);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void dELETEToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new UserMst(uname,2);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void rEPORTToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new UserMst(uname,3);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void aCCOUNTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new AReport(uname);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void sALLARYToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            closeExistingForm();
            Form umst = new SReport(uname);
            umst.MdiParent = this;
            umst.Show();
            label3.Text = "";
            pictureBox1.Visible = false; pictureBox2.Visible = false;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
